class Ruha:
    def __init__(self, nev, meret, ar):
        self.__nev = nev
        self.__meret = meret
        self.__ar = int(ar)

    def get_nev(self):
        return self.__nev
    
    def get_meret(self):
        return self.__meret
    
    def get_ar(self):
        return self.__ar

    def __str__(self):
        return f"{self.__nev} ({self.__meret}) - {self.__ar} Ft"


def beolvas():
    lista = []
    with open("ruhak.txt", "r", encoding="utf-8") as fajl:
        for sor in fajl:
            reszek = sor.strip().split()
            lista.append(Ruha(reszek[0], reszek[1], reszek[2]))
    return lista


def legdragabb_ruha(ruhak):
    legdragabb = ruhak[0]
    for ruha in ruhak:
        if ruha.get_ar() > legdragabb.get_ar():
            legdragabb = ruha
    return legdragabb


def kilegdragabb(fajlnev, ruha):
    if ruha:
        with open(fajlnev, "w", encoding="utf-8") as fajl:
            fajl.write(ruha.get_nev())


def csokkeno(ruhak):
    for i in range(len(ruhak) - 1):
        for j in range(i + 1, len(ruhak)):
            if ruhak[i].get_ar() < ruhak[j].get_ar():
                ruhak[i], ruhak[j] = ruhak[j], ruhak[i]
    return ruhak


def bekeres(ruhak, darabszam=3):
    for i in range(darabszam):
        nev = input("Add meg a ruhadarab nevét: ")
        meret = input("Add meg a méretét: ")
        ar = input("Add meg az árát: ")
        ruhak.append(Ruha(nev, meret, ar))


ruhak = beolvas()
bekeres(ruhak)

legdragabb = legdragabb_ruha(ruhak)
kilegdragabb("legdragabb.txt", legdragabb)

print("Ruhák ár szerint csökkenő sorrendben:")
for ruha in csokkeno(ruhak):
    print(ruha)
