function getCookie(name) {
    let cookies = document.cookie.split('; ');
    for (let cookie of cookies) {
        let [key, value] = cookie.split('=');
        if (key === name) return value;
    }
    return null;
}

function acceptCookies() {
    document.cookie = "cookiesAccepted=true; path=/; max-age=31536000";
    document.getElementById('cookiePopup').style.display = 'none';
}

window.onload = function() {
    if (!getCookie('cookiesAccepted')) {
        document.getElementById('cookiePopup').style.display = 'block';
    }
}